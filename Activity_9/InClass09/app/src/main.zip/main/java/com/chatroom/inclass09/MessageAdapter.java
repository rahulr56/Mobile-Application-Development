package com.chatroom.inclass09;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Raghavan on 31-Oct-16.
 */

public class MessageAdapter extends ArrayAdapter<Message.MessagesBean> {

    Context context;
    int resource;
    List<Message.MessagesBean> msgList ;
    public MessageAdapter(Context context, int resource, List<Message.MessagesBean> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        msgList = objects;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resource,parent,false);
        }

        Message.MessagesBean msg = msgList.get(position);
        ((TextView)convertView.findViewById(R.id.textViewNameChat)).setText(msg.getUserFname()+" "+msg.getUserLname());


        return convertView;
    }
}
