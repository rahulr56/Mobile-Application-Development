package com.falc0n.mymessenger;

import android.app.ProgressDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.falc0n.mymessenger.MainActivity.LOG;
import static com.falc0n.mymessenger.UsersRVAdapter.DELETE_CHAT_FLAG;
import static com.falc0n.mymessenger.UsersRVAdapter.VIEW_PROFILE_FLAG;

public class UsersActivity extends AppCompatActivity implements UsersRVAdapter.RVItemTouchListener {
    ArrayList<User> userArrayList = new ArrayList<>();
    UsersRVAdapter usersRVAdapter;
    FirebaseAuth auth = FirebaseAuth.getInstance();
    User currentUser = new User();
    ProgressDialog progressDialog;
    boolean flag = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);
        //Retrieve users from DB and display them
        //Should  be a Recycler view
        progressDialog = new ProgressDialog(getApplicationContext());
        progressDialog.setTitle("Loading Users...");
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.create();
//        progressDialog.show();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerViewUsers);
 /*       User user = new User("Rahul", "R", "M", "https://scontent-atl3-1.xx.fbcdn.net/v/t1.0-0/q82/s480x480/1044540_646838102012272_79272278_n.jpg?oh=bffc9ad8957fbe55f50279d77e12ff56&oe=58BB639D","1");
        userArrayList.add(user);
        user = new User("Ramya", "Atnoor", "F", "https://scontent-atl3-1.xx.fbcdn.net/v/t1.0-9/11891103_1142178225796919_5236860155393331765_n.jpg?oh=fe7f85172ae1193ed6ec9179e62c64c8&oe=588B79C0","2");
        userArrayList.add(user);
        user = new User("Madhuri", "Dilip Kumar", "F", "https://scontent-atl3-1.xx.fbcdn.net/t31.0-8/s960x960/14468201_1274266962605438_2773109016883308936_o.jpg","3");
        userArrayList.add(user);

       */
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);
        usersRVAdapter = new UsersRVAdapter(this, R.layout.user_item, userArrayList, this);
        recyclerView.setAdapter(usersRVAdapter);
        retrieveUsers();
        usersRVAdapter.notifyDataSetChanged();
        flag = false;
        findViewById(R.id.imageButtonUsersLogOut).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signOut();
                finish();
            }
        });
    }

    private void retrieveUsers() {
        //FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference().child("users");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, String> tempMap = new HashMap<>();
                userArrayList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Log.d(LOG, "Snapshot key is " + snapshot.getKey());
                    tempMap = (Map<String, String>) snapshot.getValue();
                    User user = new User();
                    user.setUserId(tempMap.get("userId"));
                    user.setFirstName(tempMap.get("firstName"));
                    user.setLastName(tempMap.get("lastName"));
                    user.setGender(tempMap.get("gender"));
                    user.setAvatarUrl(tempMap.get("avatarUrl"));
                    Log.d(LOG, "Adding user " + user.toString());
                    if (snapshot.getKey().matches(auth.getCurrentUser().getUid())) {
                        currentUser = user;
                        setProfileData(user);
                        continue;
                    }
                    userArrayList.add(user);
                }
                usersRVAdapter.notifyDataSetChanged();
                progressDialog.dismiss();
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void setProfileData(User user) {
        ((TextView)findViewById(R.id.textViewUsersUserName)).setText(user.getFirstName()+" "+user.getLastName());
        ImageView imageView = (ImageView) findViewById(R.id.imageButtonCArProfilePic);
        if(!currentUser.getAvatarUrl().matches("NO_IMAGE"))
        {
            Picasso.with(UsersActivity.this).load(user.getAvatarUrl()).into(imageView);
        }else {
            imageView.setImageResource(R.drawable.user);
            imageView.setColorFilter(Color.argb(0, 0, 0, 0));
           // imageView.setBackgroundTintList(new ColorStateList());
        }
    }

    @Override
    public void deletedItem(int position) {

    }

    @Override
    public void selectedItem(int position, int flag) {
        switch (flag) {
            case VIEW_PROFILE_FLAG:
                //Show Profile of user
                Log.d(LOG, "Selected user is " + userArrayList.get(position).getFirstName());
                break;
            case DELETE_CHAT_FLAG:
                Log.d(LOG, "Selected user to delete is " + userArrayList.get(position).getFirstName());
                //Delete Messages
                break;
        }
    }
}
